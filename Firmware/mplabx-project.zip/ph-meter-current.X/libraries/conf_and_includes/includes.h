/* 
 * File:   includes.h
 * Author: davidebortolami
 *
 * Created on 17 febbraio 2015, 16.45
 */

#ifndef INCLUDES_H
#define	INCLUDES_H

    #include <xc.h>

    #include <stdio.h>
    #include <stdarg.h>
    #include <stdlib.h>
    #include <stdbool.h>  //true and false definitions
    #include <math.h>




#endif	/* INCLUDES_H */

